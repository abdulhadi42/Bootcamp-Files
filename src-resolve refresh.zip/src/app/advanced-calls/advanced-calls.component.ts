import { Component } from '@angular/core';

@Component({
  selector: 'app-advanced-calls',
  templateUrl: './advanced-calls.component.html',
  styleUrls: ['./advanced-calls.component.css']
})
export class AdvancedCallsComponent {

}
