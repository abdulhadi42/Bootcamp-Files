import { Component } from '@angular/core';

@Component({
  selector: 'app-t92',
  templateUrl: './t92.component.html',
  styleUrls: ['./t92.component.css']
})
export class T92Component {

}
