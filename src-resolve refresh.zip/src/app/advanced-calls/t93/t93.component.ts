import { Component } from '@angular/core';

@Component({
  selector: 'app-t93',
  templateUrl: './t93.component.html',
  styleUrls: ['./t93.component.css']
})
export class T93Component {

}
