import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvancedCallsComponent } from './advanced-calls.component';

describe('AdvancedCallsComponent', () => {
  let component: AdvancedCallsComponent;
  let fixture: ComponentFixture<AdvancedCallsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdvancedCallsComponent]
    });
    fixture = TestBed.createComponent(AdvancedCallsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
