import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { StudentManagementComponent } from './student-management/student-management.component';
import { GetStudentsComponent } from './student-management/get-students/get-students.component';
import { AddStudentComponent } from './student-management/add-student/add-student.component';
import { UpdateStudentComponent } from './student-management/update-student/update-student.component';
import { DeleteStudentComponent } from './student-management/delete-student/delete-student.component';
import { GetStudentByIdComponent } from './student-management/get-student-by-id/get-student-by-id.component';
import { CourseManagementComponent } from './course-management/course-management.component';
import { AddCourseComponent } from './course-management/add-course/add-course.component';
import { DeleteCourseComponent } from './course-management/delete-course/delete-course.component';
import { UpdateCourseComponent } from './course-management/update-course/update-course.component';
import { GetCoursesComponent } from './course-management/get-courses/get-courses.component';
import { GetCourseByIdComponent } from './course-management/get-course-by-id/get-course-by-id.component';
import { AdvancedCallsComponent } from './advanced-calls/advanced-calls.component';
import { T91Component } from './advanced-calls/t91/t91.component';
import { T92Component } from './advanced-calls/t92/t92.component';
import { T93Component } from './advanced-calls/t93/t93.component';
import { StudentTableComponent } from './student-management/student-table/student-table.component';
import { CourseTableComponent } from './course-management/course-table/course-table.component';


import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    StudentManagementComponent,
    GetStudentsComponent,
    AddStudentComponent,
    UpdateStudentComponent,
    DeleteStudentComponent,
    GetStudentByIdComponent,
    CourseManagementComponent,
    AddCourseComponent,
    DeleteCourseComponent,
    UpdateCourseComponent,
    GetCoursesComponent,
    GetCourseByIdComponent,
    AdvancedCallsComponent,
    T91Component,
    T92Component,
    T93Component,
    StudentTableComponent,
    CourseTableComponent
  ],
  imports: [
    BrowserModule,

    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
