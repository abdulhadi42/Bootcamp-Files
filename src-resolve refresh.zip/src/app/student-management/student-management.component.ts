import { Component } from '@angular/core';
import { FetchStudentsService } from 'src/app/services/fetch-students/fetch-students.service'

@Component({
  selector: 'app-student-management',
  templateUrl: './student-management.component.html',
  styleUrls: ['./student-management.component.css']
})
export class StudentManagementComponent {
  students:any;

  constructor(private fetchStudentsService: FetchStudentsService) { }

  ngOnInit(): void {
    this.fetchStudentsService.fetchStudents()
      .subscribe(response => {
        this.students = response;
        
        // console.log(this.students);
      });
  }
  // onNewData(newStudents:any){
  //   this.students=newStudents;
  // }
}
