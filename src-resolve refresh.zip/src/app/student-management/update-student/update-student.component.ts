import { Component } from '@angular/core';
import { FetchStudentsService } from 'src/app/services/fetch-students/fetch-students.service'

@Component({
  selector: 'app-update-student',
  templateUrl: './update-student.component.html',
  styleUrls: ['./update-student.component.css']
})
export class UpdateStudentComponent {
  constructor(private fetchStudentsService: FetchStudentsService) { }
  studentObject = {
    "studentID": 0,
    "firstName": "",
    "lastName": "",
    "age": 0,
    "courseID": 0
  }
  UpdateStudent(StudentID_update:string,fname_update:string,lname_update:string,age_update:string,course_update:string)  {
  this.studentObject.firstName=fname_update;
  this.studentObject.lastName=lname_update;
  this.studentObject.age=parseInt(age_update);
  this.studentObject.courseID=parseInt(course_update);

    console.log("update function");
    this.fetchStudentsService.updateStudent(StudentID_update,this.studentObject);
    
  }
}
