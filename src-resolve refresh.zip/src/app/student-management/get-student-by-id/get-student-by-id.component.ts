import { Component } from '@angular/core';
import { FetchStudentsService } from 'src/app/services/fetch-students/fetch-students.service'

@Component({
  selector: 'app-get-student-by-id',
  templateUrl: './get-student-by-id.component.html',
  styleUrls: ['./get-student-by-id.component.css']
})
export class GetStudentByIdComponent {
  students: any;
  message : string="Please enter StudentID"
  constructor(private fetchStudentsService: FetchStudentsService) { }

  FetchStudentsById(id: any)  {
    // console.log(id);
    this.fetchStudentsService.fetchStudentsById(id)
      .subscribe(response => {
        this.students = [response];
        console.log(this.students);
      });
  }

}
