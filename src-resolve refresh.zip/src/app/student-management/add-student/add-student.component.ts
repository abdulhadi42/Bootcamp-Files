import { Component } from '@angular/core';
import { FetchStudentsService } from 'src/app/services/fetch-students/fetch-students.service'

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent {
  constructor(private fetchStudentsService: FetchStudentsService) { }
  studentObject = {
    "studentID": 0,
    "firstName": "",
    "lastName": "",
    "age": 0,
    "courseID": 0
  }
  AddStudent(fname:string,lname: string,age:any,course:any)  {
  this.studentObject.firstName=fname;
  this.studentObject.lastName=lname;
  this.studentObject.age=parseInt(age);
  this.studentObject.courseID=parseInt(course);

    console.log("add function");
    this.fetchStudentsService.addStudent(this.studentObject);
    
  }
  
}
