import { Component, Output, EventEmitter } from '@angular/core';
import { FetchStudentsService } from 'src/app/services/fetch-students/fetch-students.service'

@Component({
  selector: 'app-delete-student',
  templateUrl: './delete-student.component.html',
  styleUrls: ['./delete-student.component.css']
})
export class DeleteStudentComponent {
  @Output() newStudentsEvent=new EventEmitter<any>();
  newStudents:any;
  constructor(private fetchStudentsService: FetchStudentsService) { }

  DeleteStudentsById(id: any)  {
    // console.log(id+"delete function");
    this.fetchStudentsService.deleteStudentById(id)
    // .subscribe(response => {
    //   this.newStudents = response;
      
    //   console.log(response);
    // });
    this.fetchStudentsService.fetchStudents()
      .subscribe(response => {
        this.newStudents = response;
        console.log(this.newStudents);
        // this.newStudentsEvent.emit(this.newStudents);
        
        // console.log(this.students);
      });

    
  }
}
