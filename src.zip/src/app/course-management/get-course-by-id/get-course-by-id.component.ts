import { Component } from '@angular/core';

@Component({
  selector: 'app-get-course-by-id',
  templateUrl: './get-course-by-id.component.html',
  styleUrls: ['./get-course-by-id.component.css']
})
export class GetCourseByIdComponent {

}
