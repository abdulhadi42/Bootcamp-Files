import { Component } from '@angular/core';

@Component({
  selector: 'app-t91',
  templateUrl: './t91.component.html',
  styleUrls: ['./t91.component.css']
})
export class T91Component {

}
