import { ComponentFixture, TestBed } from '@angular/core/testing';

import { T93Component } from './t93.component';

describe('T93Component', () => {
  let component: T93Component;
  let fixture: ComponentFixture<T93Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [T93Component]
    });
    fixture = TestBed.createComponent(T93Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
