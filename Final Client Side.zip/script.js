// let students = [
//     {
//         "studentID": 1,
//         "firstName": "Muhammad",
//         "lastName": "Ali",
//         "age": 19,
//         "courseID": 1
//     },
//     {
//         "studentID": 2,
//         "firstName": "Muhammad",
//         "lastName": "Ali",
//         "age": 20,
//         "courseID": 2
//     },
//     {
//         "studentID": 3,
//         "firstName": "Muhammad",
//         "lastName": "Ahmed",
//         "age": 22,
//         "courseID": 4
//     }]

// let courses = [
//     {
//         "courseID": 1,
//         "courseName": "Machine Vision"
//     },
//     {
//         "courseID": 2,
//         "courseName": "Inteligent Systems"
//     },
//     {
//         "courseID": 3,
//         "courseName": "Mobile Robotics"
//     },
//     {
//         "courseID": 4,
//         "courseName": "DSA"
//     },
//     {
//         "courseID": 5,
//         "courseName": "OOP"
//     }
// ]


function listStudents(students, str = '') {
    let ST = $(`#StudentsTable${str} tbody`)
    ST.empty()
    for (s of students) {
        // console.log(s)
        ST.append('<tr><td>' + s.studentID + '</td> <td>' + s.firstName + '</td> <td>' + s.lastName + '</td> <td>' + s.age + '</td> <td>' + s.courseID + '</td> </tr>')
    }
}

function fetchStudents() {
    $.ajax({
        url: 'https://localhost:7198/api/Students',
        type: 'GET',

        success: function (data) {
            listStudents(data)
        },

    });
}

function addStudent() {
    let fname = $('#fname').val()
    let lname = $('#lname').val()
    let age = $('#age').val()
    let course = $('#course').val()

    var student = {
        "studentID": 3,
        "firstName": fname,
        "lastName": lname,
        "age": age,
        "courseID": course
    };

    $.ajax({
        url: 'https://localhost:7198/api/Students',
        type: 'PUT',
        data: JSON.stringify(student),
        contentType: 'application/json',
        success: function () {
            $('#studentForm')[0].reset();
            fetchStudents()
            alert("Added Successfully")

        },
        error: function () {
            alert("Please fill all fields")
        }
    });


}

function updateStudent() {

    let sid = $('#StudentID_update').val()
    let fname = $('#fname_update').val()
    let lname = $('#lname_update').val()
    let age = $('#age_update').val()
    let course = $('#course_update').val()

    var student = {
        "studentID": 3,
        "firstName": fname,
        "lastName": lname,
        "age": age,
        "courseID": course
    };

    $.ajax({
        url: `https://localhost:7198/api/Students/${sid}`,
        type: 'PUT',
        data: JSON.stringify(student),
        contentType: 'application/json',
        success: function () {
            $('#studentForm_update')[0].reset();
            fetchStudents()
            alert("Updated Successfully")

        },
        error: function () {
            alert("Please fill all fields")
        }

    });
}

function deleteStudent() {

    let sid = $('#StudentID_delete').val()
    if (sid) {
        $.ajax({
            url: `https://localhost:7198/api/Students/${sid}`,
            type: 'DELETE',
            success: function () {
                $('#studentForm_delete')[0].reset();
                fetchStudents()
                alert("Deleted Successfully")



            },

        });
    } else {
        alert('Please enter StudentID')
    }
}

function getStudent() {
    let sid = $('#StudentID_get').val()
    if (sid) {
        $.ajax({
            url: `https://localhost:7198/api/Students/${sid}`,
            type: 'GET',
            success: function (data) {
                listStudents([data], str = '_get')
                $('#studentForm_get')[0].reset();


            },

        });
    } else {
        alert('Please enter StudentID')
    }

}


function listCourses(courses, str = '') {
    let CT = $(`#CoursesTable${str} tbody`)
    CT.empty()
    for (c of courses) {
        // console.log(s)
        CT.append('<tr><td>' + c.courseID + '</td> <td>' + c.courseName + '</td> </tr>')
    }
}

function fetchCourses() {
    $.ajax({
        url: 'https://localhost:7198/api/Courses',
        type: 'GET',

        success: function (data) {
            listCourses(data)
        },

    });
}


function addCourse() {
    let cname = $('#cname').val()

    var course = {
        "courseName": cname
    }

    $.ajax({
        url: 'https://localhost:7198/api/Courses',
        type: 'PUT',
        data: JSON.stringify(course),
        contentType: 'application/json',
        success: function () {
            $('#courseForm')[0].reset();
            fetchCourses()
            alert("Added Successfully")
        },
        error: function () {
            alert("Please fill all fields")
        }

    });
}


function updateCourse() {
    let cid = $('#CourseID_update').val()
    let cname = $('#cname_update').val()

    var course = {
        "courseName": cname
    }

    $.ajax({
        url: 'https://localhost:7198/api/Courses/' + cid,
        type: 'PUT',
        data: JSON.stringify(course),
        contentType: 'application/json',
        success: function () {
            $('#courseForm_update')[0].reset();
            fetchCourses()
            alert("Updated Successfully")

        },
        error: function () {
            alert("Please fill all fields")
        }

    });
}


function deleteCourse() {
    let cid = $('#CourseID_delete').val()

    if (cid) {

        $.ajax({
            url: `https://localhost:7198/api/Courses/${cid}`,
            type: 'DELETE',
            success: function () {
                $('#courseForm_delete')[0].reset();
                fetchCourses()
                alert("Deleted Successfully")

            },

        });
    } else {
        alert('Please enter CourseID')
    }
}


function getCourse() {
    let cid = $('#CourseID_get').val()

    if (cid) {
        $.ajax({
            url: `https://localhost:7198/api/Courses/${cid}`,
            type: 'GET',
            success: function (data) {
                listCourses([data], str = '_get')
                $('#courseForm_get')[0].reset();


            },

        });
    } else {
        alert('Please enter CourseID')
    }
}

function T9_1() {
    $.ajax({
        url: 'https://localhost:7198/api/Task9_1_',
        type: 'GET',

        success: function (data) {

            let ST = $('#T9-1 tbody')
            ST.empty()
            for (s of data) {

                ST.append('<tr><td>' + s.studentID + '</td> <td>' + s.firstName + '</td> <td>' + s.lastName + '</td> <td>' + s.age + '</td> <td>' + s.courseID + '</td> </tr>')
            }
        },


    });
}

function T9_2() {
    let cid = $('#CourseID_t92').val()
    if (cid) {
        $.ajax({
            url: `https://localhost:7198/api/Task9_2_/${cid}`,
            type: 'GET',

            success: function (data) {

                let ST = $('#T9-2 tbody')
                ST.empty()
                for (s of data) {
                    ST.append('<tr><td>' + s.studentID + '</td> <td>' + s.firstName + '</td> <td>' + s.lastName + '</td> <td>' + s.age + '</td> <td>' + s.courseID + '</td> </tr>')
                }
            },


        });
    } else {
        alert('Please enter CourseID')
    }
}

function T9_3() {
    $.ajax({
        url: 'https://localhost:7198/api/Task9_3_',
        type: 'GET',

        success: function (data) {
            console.log(data)
            let T = $('#T9-3 tbody')
            T.empty()


            T.append('<tr><td>' + data.course.courseID + '</td> <td>' + data.course.courseName + '</td> <td>' + data.occurance + '</td> </tr>')

        },


    });
}

$(document).ready(function () {
    fetchStudents()
    fetchCourses()




}
)