import { Component,Input } from '@angular/core';

@Component({
  selector: 'app-get-courses',
  templateUrl: './get-courses.component.html',
  styleUrls: ['./get-courses.component.css']
})
export class GetCoursesComponent {
  @Input() courses: any;
  message : string="Loading..."
}
