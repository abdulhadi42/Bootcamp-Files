import { Component, Input} from '@angular/core';

@Component({
  selector: 'app-course-table',
  templateUrl: './course-table.component.html',
  styleUrls: ['./course-table.component.css']
})
export class CourseTableComponent {
  @Input() customClass: string;
  @Input() customId: string;
  @Input() courses: any;
  @Input() message: string;

}
