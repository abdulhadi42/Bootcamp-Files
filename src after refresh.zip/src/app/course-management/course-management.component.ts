import { Component, Output, EventEmitter } from '@angular/core';
import { CourseServiceService } from 'src/app/services/course-services/course-service.service'

@Component({
  selector: 'app-course-management',
  templateUrl: './course-management.component.html',
  styleUrls: ['./course-management.component.css']
})
export class CourseManagementComponent {
  courses:any;

  constructor(private CourseService: CourseServiceService) { }

  ngOnInit(): void {
    this.CourseService.fetchCourses()
      .subscribe(response => {
        this.courses = response;
        
        // console.log(this.students);
      });
  }
  onNewData(newCourses:any){
    this.courses=newCourses;
  }
}
