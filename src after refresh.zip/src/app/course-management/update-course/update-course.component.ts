import { Component, Output, EventEmitter } from '@angular/core';
import { CourseServiceService } from 'src/app/services/course-services/course-service.service'
@Component({
  selector: 'app-update-course',
  templateUrl: './update-course.component.html',
  styleUrls: ['./update-course.component.css']
})
export class UpdateCourseComponent {

  @Output() newCoursesEvent = new EventEmitter<any>();
  newCourses: any;
  constructor(private CourseService: CourseServiceService) { }
  coursesObject = {
    "courseID": 0,
    "courseName": "",
  }
  UpdateCourse(CourseID_update:any,cname_update:string)  {
    this.coursesObject.courseName=cname_update;
  
      console.log("update function");
      this.CourseService.updateCourse(CourseID_update,this.coursesObject).subscribe(() => {
        
        this.CourseService.fetchCourses()
          .subscribe(response => {
            this.newCourses = response;
            console.log(this.newCourses);
            this.newCoursesEvent.emit(this.newCourses);
          });
      },
        (error) => {
          console.log(error);
        }
  
      );;
      
    }

}
