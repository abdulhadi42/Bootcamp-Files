import { Component,Output,EventEmitter} from '@angular/core';
import { CourseServiceService } from 'src/app/services/course-services/course-service.service'

@Component({
  selector: 'app-delete-course',
  templateUrl: './delete-course.component.html',
  styleUrls: ['./delete-course.component.css']
})
export class DeleteCourseComponent {
  @Output() newCoursesEvent = new EventEmitter<any>();
  newCourses: any;
  constructor(private CourseService: CourseServiceService) { }

  DeleteCourseById(id: any) {
    // console.log(id+"delete function");
    this.CourseService.deleteCourseById(id).subscribe(() => {
      
      this.CourseService.fetchCourses()
        .subscribe(response => {
          this.newCourses = response;
          // console.log(this.newStudents);
          this.newCoursesEvent.emit(this.newCourses);
        });
    },
      (error) => {
        console.log(error);
      }
    )
  }
}
