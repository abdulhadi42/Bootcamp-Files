import { Component } from '@angular/core';
import { CourseServiceService } from 'src/app/services/course-services/course-service.service'

@Component({
  selector: 'app-get-course-by-id',
  templateUrl: './get-course-by-id.component.html',
  styleUrls: ['./get-course-by-id.component.css']
})
export class GetCourseByIdComponent {
  courses: any;
  message : string="Please enter CourseID"
  constructor(private CourseService: CourseServiceService) { }

  FetchCourseById(id: any)  {
    // console.log(id);
    this.CourseService.fetchCourseById(id)
      .subscribe(response => {
        this.courses = [response];
        console.log(this.courses);
      });
  }
}
