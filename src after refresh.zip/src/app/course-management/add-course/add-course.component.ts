import { Component, Output, EventEmitter } from '@angular/core';
import { CourseServiceService } from 'src/app/services/course-services/course-service.service'
@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent {
  @Output() newCoursesEvent = new EventEmitter<any>();
  newCourses: any;
  constructor(private CourseService: CourseServiceService) { }
  coursesObject = {
    "courseID": 0,
    "courseName": "",
  }
  AddCourse(cname: string) {
    this.coursesObject.courseName = cname;

    console.log("add function");
    this.CourseService.addCourse(this.coursesObject).subscribe(() => {

      this.CourseService.fetchCourses()
        .subscribe(response => {
          this.newCourses = response;
          console.log(this.newCourses);
          this.newCoursesEvent.emit(this.newCourses);
        });
    },
      (error) => {
        console.log(error);
      }

    );

  }

}
