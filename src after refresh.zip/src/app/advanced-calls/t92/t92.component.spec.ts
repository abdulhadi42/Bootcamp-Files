import { ComponentFixture, TestBed } from '@angular/core/testing';

import { T92Component } from './t92.component';

describe('T92Component', () => {
  let component: T92Component;
  let fixture: ComponentFixture<T92Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [T92Component]
    });
    fixture = TestBed.createComponent(T92Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
