import { Component,Input} from '@angular/core';

@Component({
  selector: 'app-get-students',
  templateUrl: './get-students.component.html',
  styleUrls: ['./get-students.component.css']
})
export class GetStudentsComponent  {
  @Input() students: any;
  message : string="Loading..."
  // constructor(private fetchStudentsService: FetchStudentsService) { }

  // ngOnInit(): void {
  //   this.fetchStudentsService.fetchStudents()
  //     .subscribe(response => {
  //       this.students = response;
        
  //       // console.log(this.students);
  //     });
  // }

}
