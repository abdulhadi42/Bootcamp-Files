import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FetchStudentsService {
  private readonly BASE_URL: string = 'https://localhost:44375/api/Students';
  constructor(private http: HttpClient) { }
  students:any;


  fetchStudents(): Observable<any> {
    // return this.httpClient.get(this.url);
    // console.log(this.http.get<any>(`${this.BASE_URL}`));

    return this.http.get<any>(`${this.BASE_URL}`);
  }

  fetchStudentsById(id: string): Observable<any> {
    // return this.httpClient.get(this.url);
    // console.log(this.http.get<any>(`${this.BASE_URL}`));

    return this.http.get<any>(`${this.BASE_URL}/${id}`);
  }

  deleteStudentById(id: string) {
    // return this.httpClient.get(this.url);
    // console.log(this.http.get<any>(`${this.BASE_URL}`));
    // console.log(1);
    return this.http.delete(`${this.BASE_URL}/${id}`);
  }

  addStudent(student: any) {
    // return this.httpClient.get(this.url);
    // console.log(this.http.get<any>(`${this.BASE_URL}`));

    return this.http.post(`${this.BASE_URL}`, student)
  }


  updateStudent(id: string,student: any) {
    // return this.httpClient.get(this.url);
    // console.log(this.http.get<any>(`${this.BASE_URL}`));

    return this.http.put(`${this.BASE_URL}/${id}`, student)
  }
}
