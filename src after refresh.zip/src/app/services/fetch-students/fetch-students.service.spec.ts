import { TestBed } from '@angular/core/testing';

import { FetchStudentsService } from './fetch-students.service';

describe('FetchStudentsService', () => {
  let service: FetchStudentsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FetchStudentsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
