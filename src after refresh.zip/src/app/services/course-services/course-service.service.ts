import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CourseServiceService {

  private readonly BASE_URL: string = 'https://localhost:44375/api/Courses';
  constructor(private http: HttpClient) { }
  // courses:any;

  fetchCourses(): Observable<any> {
    // return this.httpClient.get(this.url);
    // console.log(this.http.get<any>(`${this.BASE_URL}`));

    return this.http.get<any>(`${this.BASE_URL}`);
  }

  fetchCourseById(id: string): Observable<any> {
    // return this.httpClient.get(this.url);
    // console.log(this.http.get<any>(`${this.BASE_URL}`));

    return this.http.get<any>(`${this.BASE_URL}/${id}`);
  }

  deleteCourseById(id: string) {
    // return this.httpClient.get(this.url);
    // console.log(this.http.get<any>(`${this.BASE_URL}`));
    // console.log(1);
    return this.http.delete(`${this.BASE_URL}/${id}`);
  }

  addCourse(course: any) {
    // return this.httpClient.get(this.url);
    // console.log(this.http.get<any>(`${this.BASE_URL}`));

    return this.http.post(`${this.BASE_URL}`, course)
  }


  updateCourse(id: string,course: any) {
    // return this.httpClient.get(this.url);
    // console.log(this.http.get<any>(`${this.BASE_URL}`));

    return this.http.put(`${this.BASE_URL}/${id}`, course)
  }
}
