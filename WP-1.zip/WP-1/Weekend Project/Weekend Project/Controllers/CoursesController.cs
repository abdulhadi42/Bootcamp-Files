﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
namespace Weekend_Project.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CoursesController : Controller
    {
        private readonly string _connectionString;

        public CoursesController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        [HttpGet]
        public IActionResult GetGetAllCourses()
        {
            List<Course> courses = new List<Course>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetAllCourses", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Course cou = new Course();
                        cou.CourseID= (int)reader["CourseID"];
                        cou.CourseName = reader["CourseName"].ToString();
                        

                        courses.Add(cou);
                    }
                    connection.Close();

                }
            }
            return Ok(courses);
        }


        [HttpGet("{CourseID}")]
        public IActionResult GetCourseById(int CourseID)
        {
            Course course = new Course();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetCourseById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", CourseID);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        course.CourseID = (int)reader["CourseID"];
                        course.CourseName = reader["CourseName"].ToString();
                    }
                    connection.Close();

                }
            }
            return Ok(course);
        }


        [HttpPut("{CourseID}")]

        public IActionResult UpdateCourse(int CourseID, Course course)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("UpdateCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", CourseID);
                    command.Parameters.AddWithValue("@CourseName", course.CourseName);

                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return Ok(course);
        }

        [HttpPut]
        public IActionResult AddStudent(Course course)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("AddCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseName", course.CourseName);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return Ok();
        }


        [HttpDelete("{CourseID}")]
        public IActionResult DeleteStudent(int CourseID)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("DeleteCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", CourseID);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return Ok();
        }
    }
}
