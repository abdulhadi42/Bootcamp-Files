﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Runtime.ConstrainedExecution;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //cmdlhrdb01
            string connectionString = "Server=DESKTOP-0CVDBSG\\SQLEXPRESS;Database=5049_Weekend_Project_DB;Trusted_Connection=True;";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {


                // Execute Stored Procedure to list all Students
                using (SqlCommand command = new SqlCommand("AddStudent", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@FirstName", "Abdul");
                    command.Parameters.AddWithValue("@LastName", "Hadi");
                    command.Parameters.AddWithValue("@Age", 23);
                    command.Parameters.AddWithValue("@CourseID", 5);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }


                // Execute Stored Procedure to update age of Student
                using (SqlCommand command = new SqlCommand("UpdateStudent", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", 11);
                    command.Parameters.AddWithValue("@NewAge", 23);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }

                // Execute Stored Procedure to delete a Student
                using (SqlCommand command = new SqlCommand("DeleteStudent", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", 11);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }


                
                // Execute Stored Procedure to list all Students
                using (SqlCommand command = new SqlCommand("GetAllStudents", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Console.WriteLine($"StudentID: {reader["StudentID"]} , Fisrt Name: {reader["FirstName"]} , Last Name: {reader["LastName"]} , Age: {reader["Age"]} , CourseID: {reader["CourseID"]}");
                    }
                    connection.Close();
                }

                // Execute Stored Procedure to get Student by ID
                using (SqlCommand command = new SqlCommand("GetStudentById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", 5);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Console.WriteLine($"StudentID: {reader["StudentID"]} , Fisrt Name: {reader["FirstName"]} , Last Name: {reader["LastName"]} , Age: {reader["Age"]} , CourseID: {reader["CourseID"]}");
                    }
                    connection.Close();
                }





                // Execute Stored Procedure to list all Courses
                using (SqlCommand command = new SqlCommand("AddCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseName", "DBMS");
                    
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }


                // Execute Stored Procedure to update age of Course
                using (SqlCommand command = new SqlCommand("UpdateCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", 6);
                    command.Parameters.AddWithValue("@CourseName", "RDBMS");
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }

                // Execute Stored Procedure to delete a Course
                using (SqlCommand command = new SqlCommand("DeleteCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", 6);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }



                // Execute Stored Procedure to list all Course
                using (SqlCommand command = new SqlCommand("GetAllCourses", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Console.WriteLine($"CourseID: {reader["CourseID"]} , Course Name: {reader["CourseName"]}");
                    }
                    connection.Close();
                }

                // Execute Stored Procedure to get Course by ID
                using (SqlCommand command = new SqlCommand("GetCourseById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@StudentID", 5);

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Console.WriteLine($"CourseID: {reader["CourseID"]} , Course Name: {reader["CourseName"]}");
                    }
                    connection.Close();
                }


            }

            Console.ReadLine();
        }

    }
}
