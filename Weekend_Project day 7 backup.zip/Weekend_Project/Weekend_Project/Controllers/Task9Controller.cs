﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace Weekend_Project.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class Task9_1_Controller : Controller
    {
        private readonly string _connectionString;

        public Task9_1_Controller(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        [HttpGet]
        public IActionResult Task9_1()
        {
            List<Student> students = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("Task9_1", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Student stu = new Student();
                        stu.StudentID = (int)reader["StudentID"];
                        stu.FirstName = reader["FirstName"].ToString();
                        stu.LastName = reader["LastName"].ToString();

                        stu.Age = (int)reader["Age"];
                        stu.CourseID = (int)reader["CourseID"];

                        students.Add(stu);
                    }
                    connection.Close();

                }
            }
            return Ok(students);
        }
    }

    [ApiController]
    [Route("api/[controller]")]
    public class Task9_2_Controller : Controller
    {
        private readonly string _connectionString;
        public Task9_2_Controller(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }
        [HttpGet("{CourseID}")]
        public IActionResult Task9_2(int CourseID)
        {
            List<Student> students = new List<Student>();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("Task9_2", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseID", CourseID);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Student stu = new Student();
                        stu.StudentID = (int)reader["StudentID"];
                        stu.FirstName = reader["FirstName"].ToString();
                        stu.LastName = reader["LastName"].ToString();

                        stu.Age = (int)reader["Age"];
                        stu.CourseID = (int)reader["CourseID"];

                        students.Add(stu);
                    }
                    connection.Close();

                }
            }

            return Ok(students);
        }
    }

    [ApiController]
    [Route("api/[controller]")]
    public class Task9_3_Controller : Controller
    {
        private readonly string _connectionString;
        
        public Task9_3_Controller(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }
        [HttpGet]
        public IActionResult Task9_3()
        {
            Course cou = new Course();
            CourseOccurance CO = new CourseOccurance();
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                using (SqlCommand command = new SqlCommand("Task9_3", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        
                        cou.CourseID = (int)reader["CourseID"];
                        cou.CourseName = reader["CourseName"].ToString();
                        
                        CO.course = cou;
                        CO.occurance = (int)reader["Occurance"];


                       
                    }
                    connection.Close();

                }
            }
            return Ok(CO);
        }
    }
}
