﻿namespace Weekend_Project
{
    public class Course
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; }
    }
}
