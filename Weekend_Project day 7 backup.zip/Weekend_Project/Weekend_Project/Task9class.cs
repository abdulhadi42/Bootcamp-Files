﻿namespace Weekend_Project
{
    public class CourseOccurance
    {
        public Course? course { get; set; }
        public int occurance { get; set; }
    }
}
