import { ComponentFixture, TestBed } from '@angular/core/testing';

import { T91Component } from './t91.component';

describe('T91Component', () => {
  let component: T91Component;
  let fixture: ComponentFixture<T91Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [T91Component]
    });
    fixture = TestBed.createComponent(T91Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
