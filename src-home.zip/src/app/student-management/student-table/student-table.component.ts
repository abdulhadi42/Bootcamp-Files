import { Component, Input ,OnInit} from '@angular/core';
import { FetchStudentsService } from 'src/app/services/fetch-students/fetch-students.service'



@Component({
  selector: 'app-student-table',
  templateUrl: './student-table.component.html',
  styleUrls: ['./student-table.component.css']
})
export class StudentTableComponent implements OnInit{
  @Input() customClass: string;
  @Input() customId: string;

  students: any;

  constructor(private fetchStudentsService: FetchStudentsService) { }

  ngOnInit(): void {
    this.fetchStudentsService.fetchStudents()
      .subscribe(response => {
        this.students = response;
        // console.log(this.students);
      });
  }

}

