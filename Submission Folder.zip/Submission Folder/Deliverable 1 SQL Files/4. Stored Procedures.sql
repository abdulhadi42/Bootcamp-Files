CREATE PROCEDURE GetAllStudents
AS
BEGIN
    SELECT * FROM Students;
END;
GO
 

CREATE PROCEDURE AddStudent
    @FirstName VARCHAR(50),
    @LastName VARCHAR(50),
	@Age INT,
    @CourseID INT
AS
BEGIN
    INSERT INTO Students (FirstName,LastName,Age,CourseID)
    VALUES (@FirstName,@LastName,@Age,@CourseID);
END;
GO



CREATE PROCEDURE DeleteStudent
    @StudentID INT
AS
BEGIN
    DELETE FROM Students
    WHERE StudentID = @StudentID;
END;
GO

CREATE PROCEDURE GetStudentById
    @StudentID INT
AS
BEGIN
    SELECT * FROM Students WHERE StudentID = @StudentID;
END
Go

CREATE PROCEDURE UpdateStudent
	@StudentID INT,
    @FirstName VARCHAR(50),
    @LastName VARCHAR(50),
	@Age INT,
    @CourseID INT
AS
BEGIN
    UPDATE Students SET FirstName = @FirstName,LastName = @LastName, Age = @Age, CourseID = @CourseID WHERE StudentID = @StudentID;
END
Go





CREATE PROCEDURE GetAllCourses
AS
BEGIN
    SELECT * FROM Courses;
END;
GO
 

CREATE PROCEDURE AddCourse
    @CourseName VARCHAR(50)
AS
BEGIN
    INSERT INTO Courses (CourseName)
    VALUES (@CourseName);
END;
GO



CREATE PROCEDURE DeleteCourse
    @CourseID INT
AS
BEGIN
    DELETE FROM Courses
    WHERE CourseID = @CourseID;
END;
GO

CREATE PROCEDURE GetCourseById
    @CourseID INT
AS
BEGIN
    SELECT * FROM Courses WHERE CourseID = @CourseID;
END
Go

CREATE PROCEDURE UpdateCourse
	@CourseID INT,
    @CourseName VARCHAR(50)

AS
BEGIN
    UPDATE Courses SET CourseName = @CourseName WHERE CourseID = @CourseID;
END
Go




CREATE PROCEDURE Task9_1
AS
BEGIN
    SELECT * FROM Students WHERE Age>20
END
Go

CREATE PROCEDURE Task9_2
	@CourseID INT
AS
BEGIN
    SELECT * FROM Students WHERE CourseID=@CourseID;
END
Go

CREATE PROCEDURE Task9_3
	
AS
BEGIN
    SELECT TOP 1
		c.CourseID,
		c.CourseName,
		COUNT (s.StudentID) as Occurance
		
	FROM 
		Courses c
		LEFT JOIN Students s on c.CourseID = s.CourseID
	GROUP BY
		c.CourseID,
		c.CourseName
	ORDER BY
		Occurance DESC
END
Go

