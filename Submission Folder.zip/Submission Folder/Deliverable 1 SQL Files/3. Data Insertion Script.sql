CREATE TABLE Courses(
  CourseID INT PRIMARY KEY IDENTITY(1,1),
  CourseName VARCHAR(50)
 );

 CREATE TABLE Students(
  StudentID INT PRIMARY KEY IDENTITY(1,1),
  FirstName VARCHAR(50),
  LastName VARCHAR(50),
  Age INT,
  CourseID INT,
  CONSTRAINT FK_Course
  FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
 );


INSERT INTO Courses (CourseName)
VALUES 	('Machine Vision'),
		('Inteligent Systems'),
        ('Mobile Robotics'),
        ('DSA'),
        ('OOP');


INSERT into Students (FirstName,LastName,Age,CourseID)
VALUES 	('Muhammad', 'Ali',19,1),
		('Muhammad', 'Ali',20,2),
		('Muhammad', 'Ahmed',22,4),
		('Ali', 'Hamza',18,5),
		('Muhammad', 'Haseeb',24,3),
		('Usman', 'Tariq',20,2),
		('Shaheer', 'Khan',21,5),
		('Dawood', 'Imtiaz',21,4),
		('Dawood', 'Tahir',22,2),
		('Usman', 'Irshad',23,1);