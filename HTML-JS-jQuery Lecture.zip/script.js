let students=[
    {
        "studentID": 1,
        "firstName": "Muhammad",
        "lastName": "Ali",
        "age": 19,
        "courseID": 1
    },
    {
        "studentID": 2,
        "firstName": "Muhammad",
        "lastName": "Ali",
        "age": 20,
        "courseID": 2
    },
    {
        "studentID": 3,
        "firstName": "Muhammad",
        "lastName": "Ahmed",
        "age": 22,
        "courseID": 4
    }]

let courses=[
    {
        "courseID": 1,
        "courseName": "Machine Vision"
    },
    {
        "courseID": 2,
        "courseName": "Inteligent Systems"
    },
    {
        "courseID": 3,
        "courseName": "Mobile Robotics"
    },
    {
        "courseID": 4,
        "courseName": "DSA"
    },
    {
        "courseID": 5,
        "courseName": "OOP"
    }
]


function listStudents(){
    let ST= $('#StudentsTable tbody')
    ST.empty()
    for (s of students){
        // console.log(s)
        ST.append('<tr><td>'+s.studentID+'</td> <td>'+s.firstName+'</td> <td>'+s.lastName+'</td> <td>'+s.age+'</td> <td>'+s.courseID+'</td> </tr>')
    }
}

function addStudent(){
    let fname=$('#fname').val()
    let lname=$('#lname').val()
    let age=$('#age').val()
    let course=$('#course').val()

    var student = {
        "studentID": 3,
        "firstName": fname,
        "lastName": lname,
        "age": age,
        "courseID": course
    };

    students.push(student)
    $('#studentForm')[0].reset();
    listStudents()
    
}


function listCourses(){
    let CT= $('#CoursesTable tbody')
    CT.empty()
    for (c of courses){
        // console.log(s)
        CT.append('<tr><td>'+c.courseID+'</td> <td>'+c.courseName +'</td> </tr>')
    }
}

function addCourse(){
    let cname=$('#cname').val()

    var course= {
        "courseID": 5,
        "courseName": cname
    }

    courses.push(course)
    $('#courseForm')[0].reset();
    listCourses()
    
}



$(document).ready(function(){ 
    listStudents()
    listCourses()


}
)